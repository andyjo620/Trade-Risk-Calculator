import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import TradeRiskCalculator from './TradeRiskCalculator';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <TradeRiskCalculator />
  </React.StrictMode>
);