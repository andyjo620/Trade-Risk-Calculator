
import React, { useState } from "react";

export default function TradeRiskCalculator() {
  const [capital, setCapital] = useState(33000);
  const [riskPercent, setRiskPercent] = useState(1);
  const [entryPrice, setEntryPrice] = useState(0.000012);
  const [exitPrice, setExitPrice] = useState(0.000013);
  const [positionSize, setPositionSize] = useState(6600);

  const riskAmount = (capital * riskPercent) / 100;
  const tokenQuantity = entryPrice > 0 ? positionSize / entryPrice : 0;
  const exitValue = tokenQuantity * exitPrice;
  const profit = exitValue - positionSize;
  const rMultiple = riskAmount !== 0 ? profit / riskAmount : 0;
  const roi = positionSize !== 0 ? (profit / positionSize) * 100 : 0;

  return (
    <div className="p-6 max-w-xl mx-auto bg-white rounded-2xl shadow-md space-y-4">
      <h2 className="text-2xl font-bold">Trade Risk Calculator</h2>

      <div className="grid grid-cols-2 gap-4">
        <label>
          Capital ($)
          <input
            type="number"
            value={capital}
            onChange={(e) => setCapital(Number(e.target.value))}
            className="w-full border p-2 rounded"
          />
        </label>
        <label>
          Risk %
          <input
            type="number"
            value={riskPercent}
            onChange={(e) => setRiskPercent(Number(e.target.value))}
            className="w-full border p-2 rounded"
          />
        </label>
        <label>
          Entry Price
          <input
            type="number"
            value={entryPrice}
            onChange={(e) => setEntryPrice(Number(e.target.value))}
            className="w-full border p-2 rounded"
          />
        </label>
        <label>
          Exit Price
          <input
            type="number"
            value={exitPrice}
            onChange={(e) => setExitPrice(Number(e.target.value))}
            className="w-full border p-2 rounded"
          />
        </label>
        <label className="col-span-2">
          Position Size ($)
          <input
            type="number"
            value={positionSize}
            onChange={(e) => setPositionSize(Number(e.target.value))}
            className="w-full border p-2 rounded"
          />
        </label>
      </div>

      <div className="space-y-2 pt-4">
        <p>
          <strong>Risk Amount:</strong> ${riskAmount.toFixed(2)}
        </p>
        <p>
          <strong>Token Quantity:</strong> {tokenQuantity.toLocaleString(undefined, {
            maximumFractionDigits: 2,
          })}
        </p>
        <p>
          <strong>Exit Value:</strong> ${exitValue.toFixed(2)}
        </p>
        <p>
          <strong>Profit:</strong> ${profit.toFixed(2)}
        </p>
        <p>
          <strong>R-Multiple:</strong> {rMultiple.toFixed(2)}R
        </p>
        <p>
          <strong>ROI:</strong> {roi.toFixed(2)}%
        </p>
      </div>

      {/* PWA Support */}
      <link rel="manifest" href="/manifest.json" />
      <meta name="theme-color" content="#ffffff" />
      <meta name="apple-mobile-web-app-capable" content="yes" />
      <meta name="apple-mobile-web-app-status-bar-style" content="default" />
      <meta name="apple-mobile-web-app-title" content="Trade Risk Calculator" />
      <link rel="apple-touch-icon" href="/icon-192x192.png" />
    </div>
  );
}
